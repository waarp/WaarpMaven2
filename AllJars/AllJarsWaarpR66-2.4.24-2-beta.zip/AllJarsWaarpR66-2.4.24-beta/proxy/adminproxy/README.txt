The following directories must be copied or linked from httpadmin to complete this directory :
- proxy/adminproxy/gre => httpadmin/gre
- proxy/adminproxy/img => httpadmin/img
- proxy/adminproxy/res => httpadmin/res
