This directory is reserved to store the configuration of Waarp
instances, each in its own subdirectory.
