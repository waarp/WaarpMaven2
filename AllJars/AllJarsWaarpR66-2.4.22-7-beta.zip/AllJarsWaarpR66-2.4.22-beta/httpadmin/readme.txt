In your XML configuration file, set server/httpadmin to the desired directory.
Dans votre fichier XML de configuration, positionnez server/httpadmin au repertoire desire.

- en-light : light version of english Web waarp administrator
- en : full version in english
- fr : version complete en francais
- i18n : adaptable version, and dynamic (fr,en supported) PREFERED VERSION

